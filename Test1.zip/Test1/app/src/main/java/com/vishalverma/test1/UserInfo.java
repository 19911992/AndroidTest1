package com.vishalverma.test1;

/**
 * Created by vishalverma on 2017-12-05.
 */

public class UserInfo
{
    String UserEmailId;
    String UserPwd;

    //Getters

    public String getUserEmailId() {
        return UserEmailId;
    }

    public String getUserPwd()
    {
        return UserPwd;
    }


    //Setters

    public void setUserEmailId(String userEmailId)
    {
        UserEmailId = userEmailId;
    }

    public void setUserPwd(String userPwd)
    {
        UserPwd = userPwd;
    }
}
