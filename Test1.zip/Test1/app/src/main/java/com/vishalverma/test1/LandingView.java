package com.vishalverma.test1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

/**
 * Created by vishalverma on 2017-12-05.
 */

public class LandingView extends AppCompatActivity
{
    ListView listView;
    Button btn_Return, btn_Toolbar;
    TextView textView_UserEmailId;
    String [] productNamesWithDiscount = new String[]{"Product 1", "Product 2", "Product 3", "Product 4", "Product 5", "Product 6"};
    String [] productNamesWithNoDiscount = new String[]{"Product A", "Product B", "Product C", "Product D", "Product E", "Product F"};

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landingview);

        initView();

        String userEnterBy = getIntent().getStringExtra("userEnterBy");
        String userEmailId = getIntent().getStringExtra("UserEmailId");

        if(userEnterBy.equals("Login"))
        {
            btn_Toolbar.setText("Product With Discount");
            textView_UserEmailId.setText(userEmailId);
        }
        else
        {
            btn_Toolbar.setText("Product With No Discount");
            textView_UserEmailId.setText("Guest");
        }
    }

    public void initView()
    {
        listView = (ListView) findViewById(R.id.list_view);
        textView_UserEmailId = (TextView) findViewById(R.id.textView_UserEmailId);
        btn_Return = (Button) findViewById(R.id.btn_Return);
        btn_Toolbar = (Button) findViewById(R.id.btn_Toolbar);

        btn_Return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        String userEnterBy = getIntent().getStringExtra("userEnterBy");

        if(userEnterBy.equals("Login"))
        {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(LandingView.this, android.R.layout.simple_list_item_1, productNamesWithDiscount);
            listView.setAdapter(adapter);
        }
        else
        {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(LandingView.this, android.R.layout.simple_list_item_1, productNamesWithNoDiscount);
            listView.setAdapter(adapter);
        }
    }
}
