package com.vishalverma.test1;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by vishalverma on 2017-12-05.
 */

public class DbHelper extends SQLiteOpenHelper
{

    public DbHelper(Context context)
    {
        super(context, "UsersDb", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        sqLiteDatabase.execSQL(
                "create table Users (emailid text NOT NULL, pwd text NOT NULL)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1)
    {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Users");
        onCreate(sqLiteDatabase);
    }

    public long InsertUserInfo(UserInfo userInfo)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("emailid", userInfo.getUserEmailId().toString());
        values.put("pwd", userInfo.getUserPwd().toString());

        long response = db.insert("Users",null, values);

        return response;
    }
}
