package com.vishalverma.test1;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity
{
    Button btn_Login, btn_Guest;
    TextView textView_ClickToRegister;
    EditText editText_EmailId, editText_Password;
    LinearLayout linearLayout_Login;
    DbHelper myDb;

    String userEnterBy = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login);

        HideKeyboard();
        initView();

        myDb =  new DbHelper(LoginActivity.this);
    }

    public void HideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        HideKeyboard();
        finish();
    }

    public void initView() {
        btn_Login = (Button) findViewById(R.id.btn_Login);
        btn_Guest = (Button) findViewById(R.id.btn_Guest);
        textView_ClickToRegister = (TextView) findViewById(R.id.textView_ClickToRegister);
        editText_EmailId = (EditText) findViewById(R.id.editText_EmailId);
        editText_Password = (EditText) findViewById(R.id.editText_Password);
        linearLayout_Login = (LinearLayout) findViewById(R.id.linearLayout_Login);

        linearLayout_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HideKeyboard();
            }
        });

        btn_Guest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HideKeyboard();
                userEnterBy = "Guest";
                Intent intent = new Intent(LoginActivity.this, LandingView.class);
                intent.putExtra("userEnterBy",userEnterBy);
                startActivity(intent);
            }
        });

        textView_ClickToRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });

        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HideKeyboard();
                if (editText_EmailId.getText().toString().equals("") || editText_EmailId.getText().toString().equals(null)) {
                    Toast.makeText(LoginActivity.this, "Please enter your Email-Id.", Toast.LENGTH_LONG).show();
                } else if (editText_Password.equals("")) {
                    Toast.makeText(LoginActivity.this, "Please enter your password.", Toast.LENGTH_LONG).show();
                } else {
                    String user_Email = editText_EmailId.getText().toString().trim();
                    String user_Pwd = editText_Password.getText().toString().trim();

                    String query = "Select * From Users where emailid = '" + user_Email + "'";

                    SQLiteDatabase db = myDb.getReadableDatabase();
                    Cursor cursor = db.rawQuery(query, null);

                    if(cursor.getCount() > 0)
                    {
                        userEnterBy = "Login";

                        Intent intent = new Intent(LoginActivity.this, LandingView.class);
                        intent.putExtra("userEnterBy",userEnterBy);
                        intent.putExtra("UserEmailId",editText_EmailId.getText().toString());
                        startActivity(intent);
                    }
                    else
                    {
                        Toast.makeText(LoginActivity.this, "User not found. Please register first.", Toast.LENGTH_LONG).show();
                    }
                    db.close();
                }
            }
        });
    }
}
