package com.vishalverma.test1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by vishalverma on 2017-12-05.
 */

public class SignUpActivity extends AppCompatActivity
{
    Button btn_Save;
    EditText editText_EmailId, editText_Password;
    LinearLayout linearLayout_Signup;
    DbHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        HideKeyboard();
        initView();
    }

    public void HideKeyboard()
    {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        HideKeyboard();
        finish();
    }

    public void initView()
    {
        btn_Save = (Button) findViewById(R.id.btn_Save);
        editText_EmailId = (EditText) findViewById(R.id.editText_EmailId);
        editText_Password = (EditText) findViewById(R.id.editText_Password);
        linearLayout_Signup = (LinearLayout) findViewById(R.id.linearLayout_Signup);

        linearLayout_Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HideKeyboard();
            }
        });

        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HideKeyboard();
                if(editText_EmailId.getText().toString().equals("") || editText_EmailId.getText().toString().equals(null))
                {
                    Toast.makeText(SignUpActivity.this,"Please enter your Email-Id.",Toast.LENGTH_LONG).show();
                }
                else if(editText_Password.equals(""))
                {
                    Toast.makeText(SignUpActivity.this,"Please enter your password.",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(SignUpActivity.this,"User Registered Successfully.",Toast.LENGTH_LONG).show();

                    UserInfo userInfo = new UserInfo();
                    userInfo.setUserEmailId(editText_EmailId.getText().toString());
                    userInfo.setUserPwd(editText_Password.getText().toString());

                    myDb = new DbHelper(SignUpActivity.this);
                    long response = myDb.InsertUserInfo(userInfo);

                    Toast.makeText(SignUpActivity.this,"Response"+response,Toast.LENGTH_LONG).show();

                    Log.i("Response", ""+response);
                    myDb.close();
                    finish();
                }
            }
        });
    }
}
